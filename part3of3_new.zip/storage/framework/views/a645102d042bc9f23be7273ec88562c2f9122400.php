<?php $__env->startSection('main_content'); ?>
        
    <div class="wrapper theme-1-active pimary-color-red">
            
        <?php echo $__env->make('layouts.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layouts.partials.sidebarLeft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layouts.partials.sidebarRight', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layouts.partials.settingsRight', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('layouts.partials.sidebarBackdropRight', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="page-wrapper">

            <?php echo $__env->yieldContent('content'); ?>

            <!-- Footer -->
            <?php echo $__env->make('layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /Footer -->

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>