<?php $__env->startSection('title'); ?>

    Showing - <?php echo e($permission->display_name); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        

      <!-- Row -->
       <div class="table-struct full-width full-height">
          <div class="table-cell vertical-align-middle auth-form-wrap-inner">
             <div class="auth-form  ml-auto mr-auto no-float">
                <div class="row">
                   <div class="col-sm-12 col-xs-12">
                      
                      <div class="panel panel-default card-view">
                         
                         <div class="panel-wrapper collapse in">
                            
                            <div class="panel-body">               

                               <div class="mb-30">
                                  <h3 class="text-center txt-dark mb-10">

                                    <?php echo e($permission->display_name); ?>

  
                                  </h3>
                               </div>   

                               <hr>

                               <div class="form-wrap">
                                 
                                  <form > 

                                     <div class="form-group">
                                            
                                        <label for="first_name" class="col-sm-3 control-label">
                                           Display Name
                                        </label>
                                        <div class="col-sm-9">
                                           <pre><?php echo e($permission->display_name); ?></pre>
                                        </div>

                                     </div>

                                     <div class="form-group">
                                            
                                        <label for="last_name" class="col-sm-3 control-label">
                                           Slug
                                        </label>
                                        <div class="col-sm-9">
                                           <pre><?php echo e($permission->name); ?></pre>
                                        </div>

                                     </div>

                                     <div  class="form-group">
                                            
                                        <label for="email" class="col-sm-3 control-label">
                                           Description
                                        </label>
                                        <div class="col-sm-9">
                                           <pre><?php echo e($permission->description); ?></pre>
                                        </div>

                                     </div>


                                     <hr>
                                     
                                  </form>

                               </div>

                            </div>

                         </div>

                      </div>   
                   </div>
                </div>
             </div>
          </div>
       </div>
       <!-- /Row --> 

    </div>
         

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>