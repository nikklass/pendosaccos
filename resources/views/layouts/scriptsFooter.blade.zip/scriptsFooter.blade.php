

<script src="{{ asset('myjs/jquery.min.js') }}"></script>

<script src="{{ asset('myjs/bootstrap.min.js') }}"></script>

<script src="{{ asset('myjs/jasny-bootstrap.min.js') }}"></script>

<script src="{{ asset('myjs/jquery.dataTables.min.js') }}"></script>

<script src="{{ asset('myjs/jquery.slimscroll.js') }}"></script>

<script src="{{ asset('myjs/toast-data.js') }}"></script>

<script src="{{ asset('myjs/moment.min.js') }}"></script>
<script src="{{ asset('myjs/jquery.simpleWeather.min.js') }}"></script>
<script src="{{ asset('myjs/simpleweather-data.js') }}"></script>

<script src="{{ asset('myjs/jquery.waypoints.min.js') }}"></script>
<script src="{{ asset('myjs/jquery.counterup.min.js') }}"></script>

<script src="{{ asset('myjs/dropdown-bootstrap-extended.js') }}"></script>

<script src="{{ asset('myjs/jquery.sparkline.min.js') }}"></script>

<script src="{{ asset('myjs/jquery.easypiechart.min.js') }}"></script>



<script src="{{ asset('myjs/owl.carousel.min.js') }}"></script>

<script src="{{ asset('myjs/Chart.min.js') }}"></script>

<script src="{{ asset('myjs/raphael.min.js') }}"></script>
<script src="{{ asset('myjs/morris.min.js') }}"></script>
<script src="{{ asset('myjs/jquery.toast.min.js') }}"></script>

<script src="{{ asset('myjs/switchery.min.js') }}"></script>

<script src="{{ asset('myjs/init.js') }}"></script>
<script src="{{ asset('myjs/dashboard-data.js') }}"></script>
