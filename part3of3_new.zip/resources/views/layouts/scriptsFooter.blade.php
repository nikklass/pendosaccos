

<script src="/myjs/jquery.min.js"></script>

<script src="/myjs/bootstrap.min.js"></script>

<script src="/myjs/jasny-bootstrap.min.js"></script>

<script src="/myjs/jquery.dataTables.min.js"></script>

<script src="/myjs/jquery.slimscroll.js"></script>

<script src="/myjs/toast-data.js"></script>

<script src="/myjs/moment.min.js"></script>
<script src="/myjs/jquery.simpleWeather.min.js"></script>
<script src="/myjs/simpleweather-data.js"></script>

<script src="/myjs/jquery.waypoints.min.js"></script>
<script src="/myjs/jquery.counterup.min.js"></script>

<script src="/myjs/dropdown-bootstrap-extended.js"></script>

<script src="/myjs/jquery.sparkline.min.js"></script>

<script src="/myjs/jquery.easypiechart.min.js"></script>



<script src="/myjs/owl.carousel.min.js"></script>

<script src="/myjs/Chart.min.js"></script>

<script src="/myjs/raphael.min.js"></script>
<script src="/myjs/morris.min.js"></script>
<script src="/myjs/jquery.toast.min.js"></script>

<script src="/myjs/switchery.min.js"></script>

<script src="/myjs/init.js"></script>
<script src="/myjs/dashboard-data.js"></script>
