<?php $__env->startSection('main_content'); ?>
        
    <div class="page-wrapper wrapper pa-0 ma-0 auth-page">

        <?php echo $__env->make('layouts.partials.authHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>
           
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>