<footer class="footer container-fluid pl-30 pr-30">
   <div class="row">
      <div class="col-sm-12">
         <p>2017 &copy; Quick Loans</p>
      </div>
   </div>
</footer>