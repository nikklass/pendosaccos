
<!-- Scripts -->
<script src="{{ asset('js/app.js') }}"></script>

<!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.4.1/vue.js"></script> -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.16.2/axios.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.4/lodash.min.js"></script>