@extends('layouts.master')

@section('title')

    Showing {{ $user->first_name }}

@endsection


@section('content')
    
    <div class="container-fluid">
        

      <!-- Row -->
       <div class="table-struct full-width full-height">
          <div class="table-cell vertical-align-middle auth-form-wrap-inner">
             <div class="auth-form  ml-auto mr-auto no-float">
                <div class="row">
                   <div class="col-sm-12 col-xs-12">
                      
                      <div class="panel panel-default card-view">
                         
                         <div class="panel-wrapper collapse in">
                            
                            <div class="panel-body">               

                               <div class="mb-30">
                                  <h3 class="text-center txt-dark mb-10">

                                    {{ $user->first_name }}
                                    &nbsp;
                                    {{ $user->last_name }}
  
                                  </h3>
                               </div>   

                               <hr>

                               <div class="form-wrap">
                                 
                                  <form > 

                                     <div class="form-group">
                                            
                                        <label for="first_name" class="col-sm-3 control-label">
                                           First Name
                                        </label>
                                        <div class="col-sm-9">
                                           <pre>{{ $user->first_name }}</pre>
                                        </div>

                                     </div>

                                     <div class="form-group">
                                            
                                        <label for="last_name" class="col-sm-3 control-label">
                                           Last Name
                                        </label>
                                        <div class="col-sm-9">
                                           <pre>{{ $user->last_name }}</pre>
                                        </div>

                                     </div>

                                     <div  class="form-group">
                                            
                                        <label for="email" class="col-sm-3 control-label">
                                           Email Address
                                        </label>
                                        <div class="col-sm-9">
                                           <pre>{{ $user->email }}</pre>
                                        </div>

                                     </div>

                                     <div  class="form-group">
                                            
                                        <label for="phone_number" class="col-sm-3 control-label">
                                           Phone Number
                                        </label>
                                        <div class="col-sm-9">
                                           <pre>{{ $user->phone_number }}</pre>
                                        </div>

                                     </div>
                                     
                                     <div class="form-group">
                                        <label for="gender" class="col-sm-3 control-label">
                                           Gender
                                           <span class="text-danger"> *</span>
                                        </label>
                                        <div class="col-sm-9">
                                           <pre>{{ $user->gender }}</pre>
                                        </div>
                                     </div>

                                     <hr>
                                     
                                  </form>

                               </div>

                            </div>

                         </div>

                      </div>   
                   </div>
                </div>
             </div>
          </div>
       </div>
       <!-- /Row --> 

    </div>
         

@endsection

