<header class="sp-header auth-header">
   <div class="sp-logo-wrap pull-left">
      
      <?php echo $__env->make('layouts.partials.headerLogo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      
   </div>
   <div class="form-group mb-0 pull-right">
      <span class="inline-block pr-10">
        <?php echo $__env->yieldContent('auth_text'); ?> 
      </span>
      <a 
        class="inline-block btn btn-info btn-rounded btn-outline" 
        href="<?php echo $__env->yieldContent('auth_button_text_url'); ?>">
        <?php echo $__env->yieldContent('auth_button_text'); ?> 
      </a>
   </div>
   <div class="clearfix"></div>
</header>