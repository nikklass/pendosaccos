<header class="sp-header auth-header">
   <div class="sp-logo-wrap pull-left">
      
      @include('layouts.partials.headerLogo')
      
   </div>
   <div class="form-group mb-0 pull-right">
      <span class="inline-block pr-10">
        @yield('auth_text') 
      </span>
      <a 
        class="inline-block btn btn-info btn-rounded btn-outline" 
        href="@yield('auth_button_text_url')">
        @yield('auth_button_text') 
      </a>
   </div>
   <div class="clearfix"></div>
</header>