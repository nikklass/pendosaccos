
  <a href="/">
     <img class="brand-img mr-10" src="/css/images/logo.png" alt="QuickLoans"/>
     <span class="brand-text">Pendo Admin</span>
  </a>
   