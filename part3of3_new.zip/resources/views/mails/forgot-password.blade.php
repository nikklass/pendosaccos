<h1>Forgot Password</h1>

<p>We have received a request from you to reset your password.</p>
<p>Click <a href="{{ $url }}/reset-password/{{ $token->token }}">here to rest your password.</p>a></p>
<p></p>
<p></p>
<p></p>
<p></p>