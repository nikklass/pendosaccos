<?php $__env->startSection('title'); ?>
    Forgot Password
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth_text'); ?>
    Don't Have an Account Yet?
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth_button_text_url'); ?>
    /register
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth_button_text'); ?>
    Register
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
       <!-- Row -->
       <div class="table-struct full-width full-height">
          <div class="table-cell vertical-align-middle auth-form-wrap">
             <div class="auth-form  ml-auto mr-auto no-float">
                <div class="row">
                   <div class="col-sm-12 col-xs-12">
                      
                      <div class="panel panel-default card-view">
                         
                         <div class="panel-wrapper collapse in">
                            
                            <div class="panel-body">               

                               <div class="mb-30">
                                  <h3 class="text-center txt-dark mb-10">Forgot Your Password?</h3>
                                  <h6 class="text-center nonecase-font txt-grey">
                                     Enter your email address below, and we’ll help you create a new password.
                                  </h6>
                               </div>   

                               <hr>

                               <div class="form-wrap">
                                  
                                  <?php if(session('status')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                  <?php endif; ?>

                                  <form class="form-horizontal" method="POST" action="<?php echo e(route('password.email')); ?>">
                                     
                                     <?php echo e(csrf_field()); ?>


                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                        <label for="email" class="col-sm-3 control-label">E-Mail Address</label>

                                        <div class="col-sm-9">
                                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                            <?php if($errors->has('email')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                     <br/>

                                     <div class="form-group">
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-9">
                                           <button type="submit" class="btn btn-primary btn-block mr-10">
                                                Send Password Reset Link
                                           </button>
                                        </div>
                                     </div>

                                     <br/>

                                     <hr>

                                     <div class="text-center">
                                        <a href="<?php echo e(route('register')); ?>">Don't Have an Account Yet? Register</a>
                                     </div>

                                  </form>

                               </div>

                            </div>

                         </div>

                      </div>   
                   </div>
                </div>
             </div>
          </div>
       </div>
       <!-- /Row -->  
    
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>