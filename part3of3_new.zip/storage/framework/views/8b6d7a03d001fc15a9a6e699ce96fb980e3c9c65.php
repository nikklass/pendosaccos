<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth_text'); ?>
    Forgot Your Password?
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth_button_text_url'); ?>
    <?php echo e(route('password.request')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth_button_text'); ?>
    Recover Password
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div id="app">

        <div class="container-fluid">
           <!-- Row -->
           <div class="table-struct full-width full-height">
              <div class="table-cell vertical-align-middle auth-form-wrap">
                 <div class="auth-form  ml-auto mr-auto no-float">
                    <div class="row">
                       <div class="col-sm-12 col-xs-12">
                          
                          <div class="panel panel-default card-view">
                             
                             <div class="panel-wrapper collapse in">
                                
                                <div class="panel-body">               

                                   <div class="mb-30">
                                      <h3 class="text-center txt-dark mb-10">Login</h3>
                                      <h6 class="text-center nonecase-font txt-grey">Please enter your details below</h6>
                                   </div>   

                                   <hr>

                                   <div class="form-wrap">
                                      
                                      <form class="form-horizontal"  role="form" method="POST" action="<?php echo e(route('login')); ?>">
                                         
                                         <?php echo e(csrf_field()); ?>


                                         <div  class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                            
                                            <label for="email" class="col-sm-3 control-label">
                                               Email Address
                                               <span class="text-danger"> *</span>
                                            </label>
                                            <div class="col-sm-9">
                                               <div class="input-group">
                                                  <input 
                                                      type="email" 
                                                      class="form-control" 
                                                      id="email" 
                                                      name="email"
                                                      value="<?php echo e(old('email')); ?>" required autofocus>
                                                  <div class="input-group-addon"><i class="icon-envelope-open"></i></div>
                                               </div>
                                               <?php if($errors->has('email')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                               <?php endif; ?>
                                            </div>

                                         </div>

                                         <div class="form-group">
                                            
                                            <label for="password" class="col-sm-3 control-label">
                                               Password
                                               <span class="text-danger"> *</span>
                                            </label>
                                            <div class="col-sm-9">
                                               <div class="input-group">
                                                  <input 
                                                      type="password" 
                                                      class="form-control" 
                                                      id="password" 
                                                      name="password"
                                                      required>
                                                  <div class="input-group-addon"><i class="icon-lock"></i></div>
                                               </div>
                                               <?php if($errors->has('password')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                               <?php endif; ?>

                                            </div>
                                          </div>

                                          <div class="form-group">
                                              <div class="col-sm-3"></div>
                                              <div class="col-sm-9">
                                                 <div class="checkbox">
                                                    <input id="remember" type="checkbox" name="remember" 
                                                      <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                    <label for="remember"> Remember Me</label>
                                                 </div>
                                              </div>
                                           </div>

                                         <br/>

                                         <div class="form-group">
                                            <div class="col-sm-3"></div>
                                            <div class="col-sm-9">
                                               <button type="submit" class="btn btn-primary btn-block mr-10">Submit</button>
                                            </div>
                                         </div>

                                         <br/>

                                         <hr>

                                         <div class="text-center">

                                            <a href="<?php echo e(route('password.request')); ?>">
                                                Forgot Password
                                            </a>
                                            
                                         </div>

                                      </form>

                                   </div>

                                </div>

                             </div>

                          </div>   
                       </div>
                    </div>
                 </div>
              </div>
           </div>
           <!-- /Row -->  
        
        </div>  

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.authMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>