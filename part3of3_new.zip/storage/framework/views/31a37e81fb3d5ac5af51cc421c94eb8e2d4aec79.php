<?php $__env->startSection('title'); ?>

    Edit Permission - <?php echo e($permission->display_name); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">

      <!-- Row -->
       <div class="table-struct full-width full-height">
          <div class="table-cell vertical-align-middle auth-form-wrap-inner">
             <div class="ml-auto mr-auto no-float">
                <div class="row">
                   <div class="col-sm-12 col-xs-12">
                      
                      <div class="panel panel-default card-view">
                         
                         <div class="panel-wrapper collapse in">
                            
                            <div class="panel-body">               

                               <div class="mb-30">
                                  <h3 class="text-center txt-dark mb-10">
                                      Edit Permission - <?php echo e($permission->display_name); ?>

                                  </h3>
                               </div>   

                               <hr>

                               <div class="form-wrap">
                                  
                                  <?php if(session('message')): ?>
                                    <div class="alert alert-success text-center">
                                        <?php echo e(session('message')); ?>

                                    </div>
                                  <?php endif; ?>

                                  
                                  <form class="form-horizontal" method="POST" 
                                      action="<?php echo e(route('permissions.update', $permission->id)); ?>"> 

                                     <?php echo e(method_field('PUT')); ?>

                                     <?php echo e(csrf_field()); ?>


                                     <div  class="form-group<?php echo e($errors->has('display_name') ? ' has-error' : ''); ?>">
                                            
                                        <label for="display_name" class="col-sm-3 control-label">
                                           Name (Display Name) e.g. Create Post
                                           <span class="text-danger"> *</span>
                                        </label>
                                        <div class="col-sm-9">
                                           <div class="input-group">
                                              <input 
                                                  type="text" 
                                                  class="form-control" 
                                                  id="display_name" 
                                                  name="display_name"
                                                  value="<?php echo e($permission->display_name); ?>" required autofocus>
                                              <div class="input-group-addon"><i class="icon-user"></i></div>
                                           </div>
                                           <?php if($errors->has('display_name')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('display_name')); ?></strong>
                                                </span>
                                           <?php endif; ?>
                                        </div>

                                     </div>

                                     <div  class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                            
                                        <label for="name" class="col-sm-3 control-label">
                                           Slug e.g. create-post
                                        </label>
                                        <div class="col-sm-9">
                                           <div class="input-group">
                                              <input 
                                                  type="text" 
                                                  class="form-control" 
                                                  id="name" 
                                                  name="name"
                                                  value="<?php echo e($permission->name); ?>" required>
                                              <div class="input-group-addon"><i class="icon-user"></i></div>
                                           </div>
                                           <?php if($errors->has('name')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                           <?php endif; ?>
                                        </div>

                                     </div>

                                     <div  class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                            
                                        <label for="description" class="col-sm-3 control-label">
                                           Description e.g. Allows User To Create a Post
                                        </label>
                                        <div class="col-sm-9">
                                           <div class="input-group">
                                              <input 
                                                  type="text" 
                                                  class="form-control" 
                                                  id="description" 
                                                  name="description"
                                                  value="<?php echo e($permission->description); ?>" required>
                                              <div class="input-group-addon"><i class="icon-envelope-open"></i></div>
                                           </div>
                                           <?php if($errors->has('description')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                                </span>
                                           <?php endif; ?>
                                        </div>

                                     </div>

                                     <hr>

                                     <div class="form-group">
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-9">
                                            <button 
                                              type="submit" 
                                              class="btn btn-primary btn-block mr-10"
                                               id="submit-btn"
                                               @click="handleSubmit()">
                                               Submit
                                            </button>
                                        </div>
                                     </div>

                                     <br/>                                     

                                  </form>

                               </div>

                            </div>

                         </div>

                      </div>   
                   </div>
                </div>
             </div>
          </div>
       </div>
       <!-- /Row --> 
        

    </div>
         

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page_scripts'); ?>

  <script type="text/javascript">

      var app = new Vue({
        el: "#app",
        
        data() {
            return {
            }
        },
        
        methods : {

            handleSubmit() {
                $("#submit-btn").LoadingOverlay("show")
            }
            
        }

      });
  </script>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>